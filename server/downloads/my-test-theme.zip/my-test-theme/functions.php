<?php

define('WP_THEME_UPDATER_API_URL', 'http://capstone.swashcap.com/update/');
define('WP_THEME_UPDATER_ALWAYS_UPDATE', true);

require_once get_template_directory() . '/inc/class-wp-theme-updater-client.php';
