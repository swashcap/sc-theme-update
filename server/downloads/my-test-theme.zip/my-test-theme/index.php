<!doctype type>
<html>
  <head>
    <?php wp_head(); ?>
  </head>
  <body>
    <?php
      while (have_posts()) :
        the_post();
    ?>
      <article <?php post_class(); ?>>
        <h1><?php the_title(); ?></h1>
        <?php the_content(); ?>
      </article>
    <?php
      endwhile;
    ?>
  </body>
</html>